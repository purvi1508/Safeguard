def safe_function():
    print("This is safe")

safe_function()
