code = "print('Hello World')"
eval(code)
