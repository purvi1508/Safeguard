api_key = "AKIAIOSFODNN7EXAMPLE"
password = "p@ssw0rd123"
normal_var = "hello world"

def foo():
    secret_token = "s3cr3t-t0k3n-value"
    print("This is a test")
